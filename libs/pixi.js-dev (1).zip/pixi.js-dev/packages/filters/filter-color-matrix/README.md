# @pixi/filter-color-matrix

## Installation

```bash
npm install @pixi/filter-color-matrix
```

## Usage

```js
import '@pixi/filter-color-matrix';
```