# @pixi/filter-noise

## Installation

```bash
npm install @pixi/filter-noise
```

## Usage

```js
import '@pixi/filter-noise';
```