# @pixi/canvas-renderer

## Installation

```bash
npm install @pixi/canvas-renderer
```

## Usage

```js
import { CanvasRenderer } from '@pixi/canvas-renderer';
```