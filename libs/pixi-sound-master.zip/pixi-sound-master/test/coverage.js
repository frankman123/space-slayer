require("./")("../coverage/pixi-sound");
require("./")("../coverage/pixi-sound", true);
