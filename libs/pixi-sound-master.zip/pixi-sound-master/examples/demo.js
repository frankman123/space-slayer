"use strict";

const electron = require("./lib/electron");
electron("demo.html");
