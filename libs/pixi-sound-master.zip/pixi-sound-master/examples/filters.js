"use strict";

const electron = require("./lib/electron");
electron("filters.html");
